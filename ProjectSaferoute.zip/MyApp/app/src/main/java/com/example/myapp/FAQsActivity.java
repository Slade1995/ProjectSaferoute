package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class FAQsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faqs);

        // Enable the up button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(R.string.faqsActivityTitle);
        }

        // Initialize the ListView
        ListView faqListView = findViewById(R.id.faqs_list_view);

        // Create an array of FAQs
        final String[] faqs = {
                "What is Project Saferoute?",
                "How do I use the navigation tool?",
                "What should I do if I encounter a problem?",
                "How can I customize my settings?",
                "Who can I contact for support?"
        };

        // Create an array of FAQ details
        final String[] faqDetails = {
                "Project Saferoute is a safety and navigation tool designed to help people" +
                        " navigate space's that they are unfamiliar with",
                "To use the navigation tool, you can navigate to the navigation tab in the services page." +
                        "Once there enter your destination you'd like to be guided to and the app will do the rest.",
                "If you encounter a problem, you should contact the helpdesk through the app, they will" +
                        "assist with any problems or concerns you have regarding saferoute.",
                "You can customize your settings by going to the settings page in the services tab",
                "For support, you can contact security or helpdesk."
        };

        // Set the adapter to display the FAQs using the custom layout
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                R.layout.list_item_faq, R.id.faq_item_text, faqs);
        faqListView.setAdapter(adapter);

        // Set an item click listener on the ListView
        faqListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Create an intent to open the FAQDetailActivity
                Intent intent = new Intent(FAQsActivity.this, FAQDetailActivity.class);
                // Pass the selected FAQ detail to the FAQDetailActivity
                intent.putExtra("FAQ_DETAIL", faqDetails[position]);
                // Start the FAQDetailActivity
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // This will close the current activity and go back to the previous one
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}