package com.example.myapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SendMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);

        // Enable the up button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(R.string.sendMessageActivityTitle);
        }

        // Setup Send Message Button
        Button sendButton = findViewById(R.id.send_message_button);
        EditText messageEditText = findViewById(R.id.message_edit_text);

        sendButton.setOnClickListener(v -> {
            String message = messageEditText.getText().toString();
            if (!message.isEmpty()) {
                // Logic to send the message
                Toast.makeText(SendMessageActivity.this, "Message Sent: " + message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SendMessageActivity.this, "Please enter a message", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // This will close the current activity and go back to the previous one
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}