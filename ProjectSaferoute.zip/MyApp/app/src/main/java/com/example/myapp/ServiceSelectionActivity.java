package com.example.myapp;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Objects;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class ServiceSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_selection);

        // Map navigation tool button
        ImageButton mapButton = findViewById(R.id.map_navigation_tool);
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServiceSelectionActivity.this, MapActivity.class);
                startActivity(intent);
            }
        });

        // Doggo companion button
        ImageButton doggoButton = findViewById(R.id.Doggo);
        doggoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServiceSelectionActivity.this, Doggo.class);
                startActivity(intent);
            }
        });

        // Settings button
        ImageButton settingsButton = findViewById(R.id.settings);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServiceSelectionActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        // Help & Support button
        Button helpSupportButton = findViewById(R.id.help_support_button);
        helpSupportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ServiceSelectionActivity.this, HelpdeskActivity.class);
                startActivity(intent);
            }
        });
    }
}

