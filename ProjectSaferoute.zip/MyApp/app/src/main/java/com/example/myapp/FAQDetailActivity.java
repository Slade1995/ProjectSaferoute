package com.example.myapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class FAQDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq_detail);

        // Enable the up button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Get the FAQ detail from the intent
        String faqDetail = getIntent().getStringExtra("FAQ_DETAIL");

        // Set the FAQ detail to the TextView
        TextView faqDetailTextView = findViewById(R.id.faq_detail_text_view);
        faqDetailTextView.setText(faqDetail);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // This will close the current activity and go back to the previous one
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
